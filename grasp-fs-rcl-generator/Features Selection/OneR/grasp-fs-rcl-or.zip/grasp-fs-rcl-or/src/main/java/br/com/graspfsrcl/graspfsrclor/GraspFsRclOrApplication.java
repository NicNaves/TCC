package br.com.graspfsrcl.graspfsrclor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraspFsRclOrApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraspFsRclOrApplication.class, args);
	}

}
