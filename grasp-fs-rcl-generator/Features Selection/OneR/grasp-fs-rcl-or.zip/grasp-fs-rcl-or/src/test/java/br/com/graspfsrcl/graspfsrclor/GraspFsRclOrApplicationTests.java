package br.com.graspfsrcl.graspfsrclor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraspFsRclOrApplicationTests {

	@Test
	void contextLoads() {
	}

}
